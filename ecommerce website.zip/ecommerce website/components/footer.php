<footer class="footer">

   <section class="grid">

      <div class="box" >
         <h3>quick links</h3>
         <a href="home.php"> <i class="fas fa-angle-right"></i> Home</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> About</a>
         <a href="shop.php"> <i class="fas fa-angle-right"></i> Shop</a>
         <a href="contact.php"> <i class="fas fa-angle-right"></i> Contact</a>
      </div>

      <div class="box">
         <h3>extra links</h3>
         <a href="user_login.php"> <i class="fas fa-angle-right"></i> Login</a>
         <a href="user_register.php"> <i class="fas fa-angle-right"></i> Register</a>
         <a href="cart.php"> <i class="fas fa-angle-right"></i> Cart</a>
         <a href="orders.php"> <i class="fas fa-angle-right"></i> Orders</a>
      </div>

      <div class="box">
         <h3>contact us</h3>
         <a href="tel:1234567890"><i class="fas fa-phone"></i> +27 737625198</a>
         <a href="mailto:Keneilwechabalala22@gmail.com"><i class="fas fa-envelope"></i> Keneilwechabalala22@gmail.com</a>
         <a href="https://www.google.com/maps/place/1815+Seretse+Khama+St,+Klipfontein+View,+Lethabong,+1685/@-26.0490802,28.1575578,17z/data=!3m1!4b1!4m6!3m5!1s0x1e956d019348c74b:0xcfe1d57ff90c244e!8m2!3d-26.0490802!4d28.1575578!16s%2Fg%2F11j8gp8zp4?entry=ttu&g_ep=EgoyMDI0MTIwOC4wIKXMDSoASAFQAw%3D%3D"><i class="fas fa-map-marker-alt"></i> 1815 Seretse Khama St</a>
      </div>

      <div class="box">
         <h3>follow us</h3>
         <a href="https://facebook.com/marketplace/create/item"><i class="fab fa-facebook-f"></i>Facebook</a>
         <a href="#"><i class="fab fa-twitter"></i>twitter</a>
         <a href="https://github.com/Nkatekocecilmathebula"><i class="fa-brands fa-github"></i>Github</a>
         <a href="https://www.linkedin.com/in/nkateko-mathebula-cecil-5840012b5"><i class="fab fa-linkedin"></i>Linkedin</a>
      </div>

   </section>

   <div class="credit">&copy; copyright @ <?= date('Y'); ?> by <span>Chabalala K</span> | all rights reserved!</div>

</footer>